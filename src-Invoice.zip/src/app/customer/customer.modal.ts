export class Customer {
    customerId?: number;
    customerName?: string;
    customerEmail?: string;
    addressLine1?: string;
    addressLine2?: string;
    state?: string;
    city?:string;
    country?: string;
    zipCode?: number;
}
