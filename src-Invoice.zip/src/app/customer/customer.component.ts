import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Customer } from './customer.modal';
import { CustomerService } from './customer.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  formData: Customer;
  isValid: boolean = true;
  constructor(public service: CustomerService, private toastr: ToastrService,private route:Router) { }

  ngOnInit(): void {
    this.formData = {
      customerName: '',
      addressLine1: '',
      addressLine2: '',
      state: '',
      country: '',
      city:'',
      zipCode: undefined,
      customerEmail: ' '
    }
  }

  validateForm() {
    this.isValid = true;
    if (this.formData.customerName.length == 0)
      this.isValid = false;
    else if (this.formData.addressLine1 == '0')
      this.isValid = false;
    else if (this.formData.customerEmail == '0')
      this.isValid = false;
    return this.isValid;
  }

  onSubmit(form: NgForm) {
    this.service.AddCustomer(form.value).subscribe(res => {
      if (form.valid) {
        console.log("Form Submitted!");
        form.reset();
      }
      this.toastr.success('Customer Added Sucessfully', 'Customer list updated');
    });
  }
}
