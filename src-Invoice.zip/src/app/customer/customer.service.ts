import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Customer } from './customer.modal';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private http: HttpClient) { }
  getCustomerList(): Observable<Customer[]> {
    return this.http.get<Customer[]>(environment.apiURL + '/Customer');
  }
  AddCustomer(body: Customer) {
    return this.http.post("http://localhost:7000/Customer", body);
  }
}
