import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Item } from './item.modal';
import { ItemService } from './item.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  formData: Item;
  pricebool: boolean = true;


  constructor(private toastr: ToastrService, private service: ItemService,private route:Router) { }

  ngOnInit(): void {
    this.formData = {
      itemName: '',
      itemDescription: '',
      itemPrice: 0, 
    
    }

  }

  onSubmit(form: NgForm) {
    this.service.AddItem(form.value).subscribe(res => {
      this.formData = res;
      if (form.valid) {
        console.log("Form Submitted!");
        form.reset();
      this.toastr.success('Product Added Sucessfully', 'Product list updated');
      }
    });
  }
  
}