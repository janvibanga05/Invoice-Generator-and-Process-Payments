import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Item } from './item.modal';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ItemService {
  
  constructor(private http: HttpClient) { }
  getItemList() {
    return this.http.get(environment.apiURL + '/Item').toPromise();
  }
  AddItem(body: Item) {

    return this.http.post("http://localhost:7000/Item", body);
  }
  
}
