import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import pdfMake from "pdfmake/build/pdfmake";
import pdfFonts from "pdfmake/build/vfs_fonts";
import { OrderService } from '../orders/order/order.service';
pdfMake.vfs = pdfFonts.pdfMake.vfs;

class Product {
  itemName: string;
  itemPrice: number;
  quantity: number;
}
class Invoice {
  customerName: string;
  address: string;
  contactNo: number;
  email: string;
  products: Product[] = [];
  additionalDetails: string;
}
@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.css']
})
export class InvoiceComponent implements OnInit {

  id?: any;
  data: any;
  customerDetails: any;
  orderValues: any;

  constructor(private orderService: OrderService, private activatedRoute: ActivatedRoute) {
    this.data = this.orderService.message;
    console.log(this.data,"-----------------data -----------------");
  }

  order: any;
  invoice = new Invoice();

  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe(params => {
      this.id = params.get('id');
      console.log(this.id);

      this.customerDetails = this.data.filter(x => x.orderId == this.id)[0];
      let product = new Product();

      // this.addProduct();

      this.invoice.customerName = this.customerDetails.customer;
      this.invoice.email = this.customerDetails.customerEmail;
      this.invoice.address = this.customerDetails.addressLine1 + ', ' + this.customerDetails.addressLine2 + ', '+ this.customerDetails.city +' ,'+ this.customerDetails.state + ', ' + this.customerDetails.country + ', ' + this.customerDetails.zipCode;

      console.log(this.invoice.customerName, this.invoice.email, this.invoice.address, " -----1-----");
      console.log(this.invoice.products);

      console.log(this.customerDetails.orderId, this.customerDetails.customer, this.customerDetails.customerEmail, this.customerDetails.customerAddress);
    })

    this.orderService.getOrderByID(this.id).subscribe(res => {
      this.order = res;
      this.orderValues = this.order.orderdetails;

      this.orderValues.forEach(element => {
        let product = new Product();
        product.itemName = element.itemName;
        product.itemPrice = element.itemPrice;
        product.quantity = element.quantity;
        console.log(product, "Assigned");
        this.addProduct(product);
      });
      console.log(this.orderValues, "--------values  ----- --");
    });

  }

  generatePDF(action = 'open') {
    console.log('reached');
    console.log(this.invoice.products);

    let docDefinition = {
      content: [
        {
          text: 'Invoice ',
          fontSize: 35,
          alignment: 'left',
          color: '#b3bef6',
          decoration: 'underline',
          bold: true,
        },
        {
          columns: [
            [
              {
                text: this.invoice.customerName,
                bold: true,
                margin: [0, 8, 0, 8],
                fontSize: 24,
              },
              { text: this.invoice.address, margin: [0, 6, 0, 6],
                fontSize: 14, },
              { text: this.invoice.email, margin: [0, 6, 0, 6],
                fontSize: 14, },
             
            ],
            [
              {
                text: `Date: ${new Date().toLocaleString()}`,
                alignment: 'right',
                margin: [0, 6, 0, 6],
              },
              {
                text: `Bill No : ${((Math.random() * 1000).toFixed(0))}`,
                alignment: 'right'
              }
            ]
          ]
        },
        {
          text: 'Order Details',
          style: 'sectionHeader',
          margin: [0, 12, 0, 12],
          fontSize: 16,
          bold:true,
        },
        {
          table: {
            headerRows: 1,
            widths: ['*', 'auto', 'auto', 'auto'],
            body: [
              ['Product', 'Price', 'Quantity', 'Amount'],
              ...this.invoice.products.map(p => ([p.itemName, p.itemPrice, p.quantity, (p.itemPrice * p.quantity).toFixed(2)])),
              [{ text: 'Total Amount', colSpan: 3 }, {}, {}, this.invoice.products.reduce((sum, p) => sum + (p.quantity * p.itemPrice), 0).toFixed(2)]
            ]
          }
        },
        {
          text:'Notes',
          style: 'sectionHeader',
          bold:true,
          margin:[0,12,0,12],
          fontsize:16,
        },
        {
          ul:[
            'Thanks for purchasing.',
            'Have a Nice Day !!'
          ],

        },

        {
          text: 'Terms and Conditions',
          style: 'sectionHeader',
          bold: true,
          margin: [0, 12, 0, 12],
          fontSize: 16,
        },
        {
          ul: [
            'Please Pay within 20 days by card',
            'Return policy is valid till 10 days.',
          ],
        }
      ],
      styles: {
        sectionHeader: {
          bold: true,
          decoration: 'underline',
          fontSize: 14,
          margin: [0, 15, 0, 15],
        },
       
      }
    };

    if (action === 'download') {
      pdfMake.createPdf(docDefinition).download();
    } else if (action === 'print') {
      pdfMake.createPdf(docDefinition).print();
    } else {
      pdfMake.createPdf(docDefinition).open();
    }

  }

  addProduct(product: Product) {
    this.invoice.products.push(product);
  }
}
