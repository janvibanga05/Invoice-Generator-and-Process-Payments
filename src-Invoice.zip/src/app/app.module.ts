import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { OrdersComponent } from './orders/orders.component';
import { OrderComponent } from './orders/order/order.component';
import { OrderItemsComponent } from './orders/order-items/order-items.component';
import { OrderService } from './orders/order/order.service';
import { MatDialogModule } from '@angular/material/dialog';
import { HttpClientModule } from '@angular/common/http';
import { ToastrModule } from 'ngx-toastr';
import { DatePipe } from '@angular/common';
import { PaymentDetailComponent } from './payment-detail/payment-detail.component';
import { ResponseComponent } from './response/response.component';
import { ProductComponent } from './product/product.component';
import { CustomerComponent } from './customer/customer.component';
import { RefundComponent } from './refund/refund.component';
import { FailedComponent } from './failed/failed.component';
import { InvoiceComponent } from './invoice/invoice.component';
import { ApprovedComponent } from './approved/approved.component';
import { ProductlistComponent } from './productlist/productlist.component';






@NgModule({
  declarations: [
    AppComponent,
    OrdersComponent,
    OrderComponent,
    OrderItemsComponent,
    PaymentDetailComponent,
    ResponseComponent,
    ProductComponent,
    CustomerComponent,
    RefundComponent,
    FailedComponent,
    InvoiceComponent,
    ApprovedComponent,
    ProductlistComponent,
  
  ],
  imports: [
    BrowserModule,    
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    MatDialogModule,
    HttpClientModule,
    ToastrModule.forRoot(),
    
  ],
  entryComponents: [OrderItemsComponent],
  providers: [OrderService, DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
