export class OrderItem {
    orderId?: number;
    orderItemId?: number;
    itemId?: number;
    itemName?: string
    itemPrice?: number;
    itemDescription?: string
    quantity?: number;
    total?: number;
}
