import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { Customer } from 'src/app/customer/customer.modal';
import { CustomerService } from 'src/app/customer/customer.service';
import { OrderItemsComponent } from '../order-items/order-items.component';
import { OrderService } from './order.service';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { switchMap, map } from 'rxjs/operators';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})

export class OrderComponent implements OnInit {
  customerList: Customer[];
  displaydate: string;
  isValid: boolean = true;
  datePipeString: string;
  OrderId: any
  todayDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
  completeAddress: string;

  constructor(
    public service: OrderService,
    private dialog: MatDialog,
    private customerservice: CustomerService,
    private toastr: ToastrService,
    private router: Router,
    private currentRoute: ActivatedRoute,
    private datePipe: DatePipe) { }

  ngOnInit(): void {
    this.OrderId = this.currentRoute.snapshot.paramMap.get("id")
    if (this.OrderId === null)
      this.resetForm();
    else {
      this.getOrderDetails(this.OrderId);
    }

    this.customerservice.getCustomerList().subscribe(res => {
      this.customerList = res as Customer[];
    });
  }

  private getOrderDetails(orderId: string) {
    console.log(orderId);
    this.service.getOrderByID(this.OrderId).pipe(
      switchMap((order) => {
        // attaching customer details in order
        return this.customerservice.getCustomerList().pipe(
          map((customers) => {
            if (!customers || !customers.length) {
              return order;
            }

            const foundCustomer = customers.find((customer) => +customer.customerId === +order.order.customerId);
            if (!foundCustomer) {
              return order;
            }

            console.log(foundCustomer);

            console.log({ ...order });

            this.completeAddress = `${foundCustomer.addressLine1}, ${foundCustomer.addressLine2 ? `${foundCustomer.addressLine2}, ` : ''}${foundCustomer.city}, ${foundCustomer.country}, ${foundCustomer.zipCode}`
            order.order = {
              ...order.order,
              DeletedOrderItemIDs : [],
              customerName: foundCustomer.customerName,
              customerEmail: foundCustomer?.customerEmail,
              AddressLine1: foundCustomer?.addressLine1,
              AddressLine2: foundCustomer?.addressLine2,
              City: foundCustomer.city,
              ZipCode: foundCustomer.zipCode,
              Country: foundCustomer.country,
            }

            return order;
          })
        )
      })
    ).subscribe((res) => {
      console.log(res);
      this.service.formData = res.order;
      this.service.orderItems = res.orderdetails;
    });
  }

  resetForm(form?: NgForm) {
    //form.resetForm();
    this.service.formData = {
      orderId: 0,
      orderNumber: Math.floor(100000 + Math.random() * 900000).toString(),
      customerId: 0,
      orderDueOn: '',
      totalAmount: 0,
      customerEmail: '',
      DeletedOrderItemIDs: [],

    };
    this.service.orderItems = [];
    console.log(this.service.orderItems);
    console.log(this.service.formData)
  }

  AddOrEditOrderItem(orderItemIndex: any, OrderId: any) //To add items in the order and in parameter pre-defined data is given
  {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = true;
    dialogConfig.disableClose = true;
    dialogConfig.width = "50%";
    dialogConfig.data = { orderItemIndex, OrderId };
    this.dialog.open(OrderItemsComponent, dialogConfig).afterClosed().subscribe(res => {
      this.updateTotalAmount();
    })
  }

  validateForm() {
    this.isValid = true;
    if (this.service.formData.customerId == 0)
      this.isValid = false;
    else if (this.service.orderItems.length == 0)
      this.isValid = false;
    else if (this.service.formData.orderDueOn && this.service.formData.orderDueOn.length == 0)
      this.isValid = false;
    return this.isValid;
  }

  onDeleteOrderItem(orderItemId: number, i: number) {
    if (orderItemId != undefined) {
        if(this.service.formData.DeletedOrderItemIDs == undefined){
          this.service.formData.DeletedOrderItemIDs = []
        }
        this.service.formData.DeletedOrderItemIDs.push(orderItemId);
    }

    this.service.orderItems.splice(i, 1);
    this.updateTotalAmount();
  }

  updateCustomerDetails(ctrl: any) {
    if (ctrl.selectedIndex == 0) {
      this.service.formData.AddressLine1 = '';
      this.service.formData.customerEmail = '';
    }
    else {
      console.log(ctrl.selectedIndex)
      this.service.formData.AddressLine1 = this.customerList[ctrl.selectedIndex - 1].addressLine1;
      this.service.formData.AddressLine2 = this.customerList[ctrl.selectedIndex - 1].addressLine2;
      this.service.formData.State = this.customerList[ctrl.selectedIndex - 1].state;
      this.service.formData.City = this.customerList[ctrl.selectedIndex - 1].city;
      this.service.formData.Country = this.customerList[ctrl.selectedIndex - 1].country;
      this.service.formData.ZipCode = this.customerList[ctrl.selectedIndex - 1].zipCode;
      this.service.formData.customerEmail = this.customerList[ctrl.selectedIndex - 1].customerEmail;
      this.completeAddress = this.service.formData.AddressLine1 + ', ' + this.service.formData.AddressLine2 + ', ' + this.service.formData.City + ' ,' + this.service.formData.State + ', ' + this.service.formData.Country + ', ' + this.service.formData.ZipCode;
      console.log(this.service.formData)
    }
  }

  updateTotalAmount() {
    this.service.formData.totalAmount = this.service.orderItems.reduce((prev, curr) => {
      return prev + curr.total;
    }, 0);
    this.service.formData.totalAmount = parseFloat(this.service.formData.totalAmount.toFixed(2));
  }

  onSubmit(form: NgForm) {
    if (this.validateForm()) {
      var customerName = this.customerList.filter(x => x.customerId == this.service.formData.customerId)[0].customerName;
      this.service.saveOrUpdateOrder(customerName).subscribe(res => {
        this.resetForm();
        console.log(res, 'order save');
        this.toastr.success('Submitted Sucessfully Invoice number', res.orderNumber);
        this.router.navigate(['/orders']);
      });
    }
  }
}