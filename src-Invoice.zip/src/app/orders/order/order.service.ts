import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { OrderItem } from '../order-items/order-item.modal';
import { Order } from './order.modal';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class OrderService {
  formData: Order;
  orderItems: OrderItem[];
  message: any;

  constructor(private http: HttpClient) { }

  setMessage(value: any) {
    this.message = value;
  }

  getMessage() {
    return this.message;
  }

  saveOrUpdateOrder(customerName: string) : Observable<any> {
    var body = {
      ...this.formData,
      Customer: {
        CustomerName : customerName,
        CustomerEmail : this.formData.customerEmail,
        CustomerId:this.formData.customerId,
        AddressLine1:this.formData.AddressLine1,
        AddressLine2:this.formData.AddressLine2,
        State:this.formData.State,
        City:this.formData.City,
        ZipCode:this.formData.ZipCode,
        Country:this.formData.Country
      },
      DeletedOrderItemIDs : this.formData.DeletedOrderItemIDs.join(','),
      OrderItems: this.orderItems
    };
    return this.http.post(environment.apiURL + '/Order', body);
  }
  getOrderList() {
    return this.http.get(environment.apiURL + '/Order/').toPromise();
  }
  getOrderByID(id: any): Observable<{ order: Order; orderdetails: OrderItem[] }> {
    return this.http.get<{ order: Order; orderdetails: OrderItem[] }>("http://localhost:7000/Order/" + id);
  }
  deleteOrder(id: number) {
    return this.http.delete("http://localhost:7000/Order/" + id)
  }
}

