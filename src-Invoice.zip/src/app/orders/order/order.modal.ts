export class Order {
    orderId?: number
    orderNumber?: string
    orderStatus?: string
    customerId?: number
    customerName?: string
    customerEmail?: string
    AddressLine1?: string;
    AddressLine2?: string;
    State?: string;
    Country?: string;
    City?:string;
    ZipCode?: number;
    paymentDetail?: string
    totalAmount?: number
    orderDueOn?: string
    DeletedOrderItemIDs?: number[]
}
