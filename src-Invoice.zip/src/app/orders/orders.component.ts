import { Component, OnInit } from '@angular/core';
import { OrderService } from './order/order.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Order } from './order/order.modal';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {

  orderList: any;
  isdisabled: boolean = false;

  constructor(
    private service: OrderService,
    private router: Router,
    private toastr: ToastrService // Add toastr service here
  ) {}

  ngOnInit(): void {
    this.refreshList();
  }

  refreshList() {
    this.service.getOrderList().then(res => {
      this.orderList = res;
      this.service.setMessage(this.orderList);
      console.log(this.service.message, ' values');
    });
  }

  passdata(orderID: any, orderNumber: any, totalAmount: any) {
    sessionStorage.setItem('OrderID', orderID);
    sessionStorage.setItem('OrderNumber', orderNumber);
    sessionStorage.setItem('TotalAmount', totalAmount);
  }

  openForEdit(OrderId: number) {
    this.router.navigate(['/order/edit/' + OrderId]);
  }

  onOrderDelete(id: number) {
    if (confirm('Are you sure to delete the record?')) {
      this.service.deleteOrder(id).subscribe(res => {
        this.refreshList();
        this.toastr.warning('Deleted successfully', 'OrderInvoice'); // Use toastr here to show the warning message
      });
    }
  }

  getStatusClass(status: string): string {
    switch (status) {
      case 'Paid':
        return 'paid';
      case 'Not Paid':
        return 'not-paid';
      case 'Partial Paid':
        return 'partial-paid';
      default:
        return '';
    }
  }
}



