import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NgForm } from '@angular/forms';
import { environment } from 'src/environments/environment';
import { PayementDetail } from './payement-detail.modal';

@Injectable({
  providedIn: 'root'
})
export class PayementDetailService {

  constructor(private http: HttpClient) { }
  formdata: PayementDetail = new PayementDetail();
  list: PayementDetail[];

  postPaymentDetail(val: any) {
    return this.http.post(environment.apiURL + '/Payment', val);
  }
  getPaymentDetails(val: any) {
    return this.http.get(environment.apiURL + '/Payment/' + val);
  }
}
