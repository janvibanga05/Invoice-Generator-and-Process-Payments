export class PayementDetail {
    OrderID: number;
    cardOwnerName: string = '';
    Amount: number;
    cardNumber: string = '';
    expirationDate: string = '';
    cvv = '';
    transactionId: string = '';
}

export interface PayementDetails {
    OrderID: number;
    cardOwnerName: string;
    Amount: number;
    cardNumber: string;
    expirationDate: string;
    transactionId: string;
    cvv: string;

}