import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PayementDetail, PayementDetails } from './payement-detail.modal';
import { PayementDetailService } from './payement-detail.service';

@Component({
  selector: 'app-payment-detail',
  templateUrl: './payment-detail.component.html',
  styleUrls: ['./payment-detail.component.css']
})
export class PaymentDetailComponent implements OnInit {
  OrderId: any;
  OrderNumber: any;
  OrderAmount: any;
  formdata: PayementDetails;
  PaymentResponse: any;
  PaymentResponseTransId: string;
  isValid: boolean = true;

  constructor(public service: PayementDetailService, private toastr: ToastrService, private router: Router) {
    this.OrderId = sessionStorage.getItem("OrderID");
    this.OrderNumber = sessionStorage.getItem("OrderNumber").toString();
    this.OrderAmount = sessionStorage.getItem("TotalAmount").toString();
    this.formdata =
    {
      Amount: this.OrderAmount,
      OrderID: this.OrderId,
      cardNumber: '',
      cardOwnerName: '',
      cvv: '',
      expirationDate: '',
      transactionId: ''
    }

  }

  ngOnInit(): void {

  }

  onSubmit() {
    this.service.postPaymentDetail(this.formdata).subscribe((res: any) => {
      console.log(res);
      this.PaymentResponse = res.messages.message[0].text;
      this.PaymentResponseTransId = res.transactionResponse.transId;
      if (res.transactionResponse.transId == 0) {
        this.router.navigate(["/failed"]);
      }
      else {
        this.router.navigate(["/response"]);
      }
      console.log(this.PaymentResponse);
      this.passdata(this.PaymentResponse, this.PaymentResponseTransId);
    })

  }
  passdata(paymentResponse: string, transId: string) {
    sessionStorage.setItem("PaymentResponse", paymentResponse);
    sessionStorage.setItem("TransactionId", transId)
  }

  validateForm(formData: any) {
    this.isValid = true;
    if (formData.cardNumber == 0)
      this.isValid = false;
    else if (formData.cardOwnerName == 0)
      this.isValid = false;
    else if (formData.cvv == 0)
      this.isValid = false;
    else if (formData.expirationDate == 0)
      this.isValid = false;
    return this.isValid;

  }


}
