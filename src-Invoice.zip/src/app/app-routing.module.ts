import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustomerComponent } from './customer/customer.component';
import { OrderComponent } from './orders/order/order.component';
import { OrdersComponent } from './orders/orders.component';
import { PaymentDetailComponent } from './payment-detail/payment-detail.component';
import { ProductComponent } from './product/product.component';
import { RefundComponent } from './refund/refund.component';
import { ResponseComponent } from './response/response.component';
import { FailedComponent } from './failed/failed.component';
import { InvoiceComponent } from './invoice/invoice.component';
import { ApprovedComponent } from './approved/approved.component';
import { ProductlistComponent } from './productlist/productlist.component';

const routes: Routes = [
  { path: 'payementdetails', component: PaymentDetailComponent },
  { path: 'response', component: ResponseComponent },
  { path: 'orders', component: OrdersComponent },
  { path: 'product', component: ProductComponent },
  { path: 'customer', component: CustomerComponent },
  { path: 'refund/:id', component: RefundComponent },
  { path: 'approved', component: ApprovedComponent },
  { path: 'invoice/:id', component: InvoiceComponent },
  { path: 'failed', component: FailedComponent },
  { path: 'productlist', component: ProductlistComponent},
  
  {
    path: 'order', children: [
      { path: '', component: OrderComponent },
      { path: 'edit/:id', component: OrderComponent },
    ]
  },
  { path: '', redirectTo: '/order', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
