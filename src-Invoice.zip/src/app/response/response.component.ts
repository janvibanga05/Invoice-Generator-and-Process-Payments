import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-response',
  templateUrl: './response.component.html',
  styleUrls: ['./response.component.css']
})
export class ResponseComponent implements OnInit {
  transactionmessage: any;
  transactionId: string;

  constructor(private router: Router) {

    this.transactionmessage = sessionStorage.getItem("PaymentResponse");
    this.transactionId = sessionStorage.getItem("TransactionId");
  }
  ngOnInit(): void {

  }
  transfer() {
    this.router.navigate(["/orders"]);
  }
}