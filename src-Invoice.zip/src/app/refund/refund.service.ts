import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RefundService {

  constructor(private http: HttpClient) { }

  RefundPayment(id:number) {

    return this.http.post("http://localhost:7000/Refund",id);
  }
}
