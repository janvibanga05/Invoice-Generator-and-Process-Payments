import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PayementDetailService } from '../payment-detail/payement-detail.service';
import { RefundService } from './refund.service';
@Component({
  selector: 'app-refund',
  templateUrl: './refund.component.html',
  styleUrls: ['./refund.component.css']
})
export class RefundComponent {
  formdata: any = {
    amount: 0,
    transactionId: ""
  };
  id: string;
  message: string;
  transactionId: string;
  constructor(public service: PayementDetailService, private refundService: RefundService, private _Activatedroute: ActivatedRoute,private router:Router, 
    private toastr: ToastrService) {
    this.RefundTransaction();
  }

  RefundTransaction() {
    this.id = this._Activatedroute.snapshot.paramMap.get("id");
    this.service.getPaymentDetails(this.id).subscribe(res => {
      this.formdata = res;
      console.log(this.formdata);
      console.log(this.formdata.transactionId);
    })
  }

  RefundResult() {
    this.refundService.RefundPayment(this.formdata).subscribe((res: any) => {
      console.log(this.formdata.transactionId);
        this.message = res.messages.message[0].text;
        this.transactionId = res.transactionResponse.transactionId;
      });
      this.router.navigate(["/approved"]);
  }
}