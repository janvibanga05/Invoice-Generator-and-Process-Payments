import { Component, OnInit } from '@angular/core';
import { Item } from '../product/item.modal';
import { ItemListService } from './productlist.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {
  myproduct?: Item[];

  constructor(
    private itemlistservice: ItemListService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {
    this.getProducts();
  }

  getProducts(): void {
    this.itemlistservice
      .getItemList()
      .subscribe((products) => {
        this.myproduct = products;
        console.log(products);
      });
  }
 
  deleteproduct(itemId: number | undefined): void {
    if (confirm('Are you sure to delete the contact?'))
      this.itemlistservice.deleteproduct(itemId).subscribe(() => {
        this.toastr.success('Product deleted successfully!');
      }, (error) => {
        this.toastr.error('Failed to delete Product');
      });
  }

}
