import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

import { Observable, Subject } from 'rxjs';
import { combineLatest } from 'rxjs';
import { startWith, switchMap, tap } from 'rxjs/operators';
import { Item } from '../product/item.modal';

@Injectable({
  providedIn: 'root'
})
export class ItemListService {
  private refreshPorductLists$$ = new Subject<void>();

  constructor(private http: HttpClient) { }

  getItemList():Observable<Item[]> {
    return combineLatest([
      this.refreshPorductLists$$.pipe(startWith(''))
    ]).pipe(
      switchMap(() => {
        return this.http.get<Item[]>(environment.apiURL + '/Item');
      })
    );
  }

  deleteproduct(id: number): Observable<Item> {
    return this.http.delete<Item>(`${environment.apiURL}/Item/Deleteproduct/${id}`).pipe(
      tap(() => this.refreshPorductLists$$.next())
    );
  }
}