export const environment = {
  production: true,
  apiURL:'http://localhost:7000'
};
