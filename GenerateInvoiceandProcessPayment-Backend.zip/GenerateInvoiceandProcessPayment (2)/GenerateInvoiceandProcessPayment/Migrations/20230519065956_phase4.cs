﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace GenerateInvoiceandProcessPayment.Migrations
{
    /// <inheritdoc />
    public partial class phase4 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Item",
                keyColumn: "ItemId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Item",
                keyColumn: "ItemId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Item",
                keyColumn: "ItemId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Item",
                keyColumn: "ItemId",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Item",
                keyColumn: "ItemId",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Item",
                keyColumn: "ItemId",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Item",
                keyColumn: "ItemId",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "Item",
                keyColumn: "ItemId",
                keyValue: 8);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Item",
                columns: new[] { "ItemId", "ItemDescription", "ItemName", "ItemPrice" },
                values: new object[,]
                {
                    { 1, "LEATHER TUBE TOP ", "ZARA TUBE TOP", 1700f },
                    { 2, "Women Bell Bottom Jeans", "BELL BOTTOM JEANS", 2500f },
                    { 3, "Nike Women Air Max Shoes", "Nike AirMax 200", 10000f },
                    { 4, "H&M Women Baggy TShirt", "Baggy-TShirt", 1000f },
                    { 5, "Maroon Belted Blazer Dress", "Belted Blazer Dress", 2700f },
                    { 6, "H&M Black Knee-High Heeled Boots ", "H&M Knee-High Heeled Boots", 5000f },
                    { 7, "Micheal Kors BradShaw Women Gold Analogue Watch MK6359", "Micheal Kors Women Watch", 9999f },
                    { 8, "Geometric Push-Lock Top Handle Bag-Black", "Charles & Keith Bag", 9500f }
                });
        }
    }
}
