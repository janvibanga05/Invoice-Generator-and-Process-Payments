using AuthorizeNet.Api.Contracts.V1;
using GenerateInvoiceandProcessPayment.Models.Entity;
using System;

namespace GenerateInvoiceandProcessPayment.Services
{
    public interface IRefundService
    {
        public ANetApiResponse Run(decimal TransactionAmount, string TransactionID);

        
        Task<int> PostItem(Refund refund);
    }
}