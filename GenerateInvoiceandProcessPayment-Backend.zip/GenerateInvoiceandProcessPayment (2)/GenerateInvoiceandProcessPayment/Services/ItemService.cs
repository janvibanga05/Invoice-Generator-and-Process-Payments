using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GenerateInvoiceandProcessPayment.Database;
using GenerateInvoiceandProcessPayment.Models.Entity;

namespace GenerateInvoiceandProcessPayment.Services
{
    public class ItemService : IItemService
    {
        AppDbContext appDbContext;

        public ItemService(AppDbContext _appDbContext)
        {
            appDbContext = _appDbContext;
        }

         async Task IItemService.Deleteitem(int id)
        {
            var item = await appDbContext.Item.FindAsync(id);
            if (item == null)
            {
                throw new ArgumentException($"Item with ID {id} not found");

            }
            appDbContext.Item.Remove(item);
            await appDbContext.SaveChangesAsync();
            
        }

        IEnumerable<Item> IItemService.GetItems()
        {
            var ItemList = appDbContext.Item.ToList();
            return ItemList.OrderBy(x=>x.ItemName);
        }

        async Task<int> IItemService.PostItem(Item items)
        {
            await appDbContext.Item.AddAsync(items);
            return await appDbContext.SaveChangesAsync();
        }
    }
}