using GenerateInvoiceandProcessPayment.Models.Entity;

namespace GenerateInvoiceandProcessPayment.Services
{
    public interface IItemService 
    {
         IEnumerable<Item> GetItems();
        Task<int> PostItem(Item item);
        Task Deleteitem(int id);
    }
}