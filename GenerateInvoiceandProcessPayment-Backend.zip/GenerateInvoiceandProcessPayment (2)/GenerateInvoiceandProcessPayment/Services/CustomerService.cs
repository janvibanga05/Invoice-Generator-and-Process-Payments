using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GenerateInvoiceandProcessPayment.Database;
using GenerateInvoiceandProcessPayment.Models.Entity;
using GenerateInvoiceandProcessPayment.ViewModel.DTO;
using Microsoft.EntityFrameworkCore;

namespace GenerateInvoiceandProcessPayment.Services
{
    public class CustomerService : ICustomerService
    {
        AppDbContext appDbContext;
        public CustomerService(AppDbContext _appDbContext)
        {
            appDbContext = _appDbContext;
        }

        IEnumerable<Customer> ICustomerService.GetCustomers()
        {
            var CustomerList = appDbContext.Customers.ToList();
            return CustomerList.OrderBy(x =>x.CustomerName);
        }

        async Task<int> ICustomerService.PostCustomer(CustomerDTO model)
        {
            var customer = new Customer(model);
            await appDbContext.Customers.AddAsync(customer);
           return await appDbContext.SaveChangesAsync();
        }
    }
}