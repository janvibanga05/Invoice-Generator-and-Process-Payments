using System;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using GenerateInvoiceandProcessPayment.Models.Entity;
using AuthorizeNet.Api.Contracts.V1;
using GenerateInvoiceandProcessPayment.Database;
using AuthorizeNet.Api.Controllers.Bases;
using AuthorizeNet.Api.Controllers;

namespace GenerateInvoiceandProcessPayment.Services
{
    public class PaymentService : IPaymentService
    {
        string TransactionID;
        AppDbContext customerDbContext;
        public IConfiguration Configuration { get; } 

        public PaymentService(AppDbContext _customerDbContext, IConfiguration _Configuration)
        {
            customerDbContext = _customerDbContext;
            Configuration = _Configuration;
        }

        //Add Payment Details
        void IPaymentService.AddPayment(Payment payment, int id)
        {
            payment.TransactionId = TransactionID;
            customerDbContext.Payments.Add(payment);
            customerDbContext.SaveChanges();
            var temp = customerDbContext.Orders.FirstOrDefault(i => i.OrderId == id);
            temp.OrderStatus = "Paid";
            customerDbContext.SaveChanges();
        }



        //Hashing of Card No, Exp date and other confidential info.
        void IPaymentService.CreateCardNumberHash(string CardNumber, string ExpirationDate, out byte[] ExpirationDateHash, out byte[] salt)
        {
            using (var hmac = new System.Security.Cryptography.HMACSHA512())
            {
                salt = hmac.Key;
                ExpirationDateHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(ExpirationDate));
            }
        }

        //API call to DoPayment
        public ANetApiResponse DoPayment(string CardNumber, string ExpirationDate, decimal Amount)
        {
            Console.WriteLine("Authorize Credit Card Sample");

            ApiOperationBase<ANetApiRequest, ANetApiResponse>.RunEnvironment = AuthorizeNet.Environment.SANDBOX; //learn

            // define the merchant information (authentication / transaction id)
            ApiOperationBase<ANetApiRequest, ANetApiResponse>.MerchantAuthentication = new merchantAuthenticationType()
            {
                name = Configuration.GetValue<string>("AuthorizeNetGateway:ApiLoginID"),
                ItemElementName = ItemChoiceType.transactionKey,
                Item = Configuration.GetValue<string>("AuthorizeNetGateway:ApiTransactionKey"),
            };

            var creditCard = new creditCardType
            {
                cardNumber = CardNumber,
                expirationDate = ExpirationDate
            };

            //standard api call to retrieve response
            var paymentType = new paymentType { Item = creditCard };

            var transactionRequest = new transactionRequestType
            {
                transactionType = transactionTypeEnum.authOnlyTransaction.ToString(),    // authorize only
                amount = Amount,
                payment = paymentType
            };

            var request = new createTransactionRequest { transactionRequest = transactionRequest };

            // instantiate the controller that will call the service
            var controller = new createTransactionController(request);
            controller.Execute();

            // get the response from the service (errors contained if any)
            var response = controller.GetApiResponse();

            // validate response
            if (response != null)
            {
                if (response.messages.resultCode == messageTypeEnum.Ok)
                {
                    if (response.transactionResponse.messages != null)
                    {
                        Console.WriteLine("Successfully created transaction with Transaction ID: " + response.transactionResponse.transId);
                        Console.WriteLine("Response Code: " + response.transactionResponse.responseCode);
                        Console.WriteLine("Message Code: " + response.transactionResponse.messages[0].code);
                        Console.WriteLine("Description: " + response.transactionResponse.messages[0].description);
                        Console.WriteLine("Success, Auth Code : " + response.transactionResponse.authCode);
                    }
                    else
                    {
                        Console.WriteLine("Failed Transaction.");
                        if (response.transactionResponse.errors != null)
                        {
                            Console.WriteLine("Error Code: " + response.transactionResponse.errors[0].errorCode);
                            Console.WriteLine("Error message: " + response.transactionResponse.errors[0].errorText);
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Failed Transaction.");
                    if (response.transactionResponse != null && response.transactionResponse.errors != null)
                    {
                        Console.WriteLine("Error Code: " + response.transactionResponse.errors[0].errorCode);
                        Console.WriteLine("Error message: " + response.transactionResponse.errors[0].errorText);
                    }
                    else
                    {
                        Console.WriteLine("Error Code: " + response.messages.message[0].code);
                        Console.WriteLine("Error message: " + response.messages.message[0].text);
                    }
                }
            }
            else
            {
                Console.WriteLine("Null Response.");
            }

            TransactionID = response.transactionResponse.transId;

            return response;
        }


        System.Object IPaymentService.GetPaymentDetails(int id)
        {
            Payment transaction = customerDbContext.Payments.FirstOrDefault(i => i.OrderId == id);
            string transactionId = transaction.TransactionId;
            decimal amount = transaction.Amount;
            var obj = new { transactionId, amount };
            return obj;
        }
    }
}