using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GenerateInvoiceandProcessPayment.Database;
using GenerateInvoiceandProcessPayment.Models.Entity;
using Microsoft.EntityFrameworkCore;
using System;
using Microsoft.AspNetCore.Mvc;


namespace GenerateInvoiceandProcessPayment.Services
{
    public class OrderService : IOrderService
    {

        AppDbContext appDbContext;
        public OrderService(AppDbContext _appDbContext)
        {
            appDbContext = _appDbContext;
        }
        void IOrderService.DeleteOrder(int id)
        {
            var deleteOrder = appDbContext.Orders.SingleOrDefault(t => t.OrderId == id);
            if (deleteOrder != null)
            {
                appDbContext.Remove(deleteOrder);
                appDbContext.SaveChanges();
            }
        }

        object IOrderService.GetOrder(int id)
        {
            var order = (from a in appDbContext.Orders
                         where a.OrderId == id

                         select new
                         {
                             a.OrderId,
                             a.OrderNumber,
                             a.CustomerId,
                             a.PaymentDetail,
                             a.TotalAmount,

                         }).FirstOrDefault();

            var orderdetails = (from a in appDbContext.OrderItems
                                join b in appDbContext.Item on a.ItemId equals b.ItemId
                                where a.OrderId == id

                                select new
                                {
                                    a.OrderId,
                                    a.OrderItemId,
                                    a.ItemId,
                                    ItemName = b.ItemName,
                                    b.ItemPrice,
                                    b.ItemDescription,
                                    a.Quantity,
                                    Total = a.Quantity * b.ItemPrice
                                }).ToList();

            var obj = new { order, orderdetails };
            return obj;
        }

        object IOrderService.GetOrders()
        {
            var result = (from a in appDbContext.Orders
                          join b in appDbContext.Customers on a.CustomerId equals b.CustomerId

                          select new
                          {
                              a.OrderId,
                              a.OrderNumber,
                              a.OrderStatus,
                              Customer = b.CustomerName,
                              CustomerEmail = b.CustomerEmail,
                              AddressLine1 = b.AddressLine1,
                              AddressLine2 = b.AddressLine2,
                              City = b.City,
                              State = b.State,
                              Country = b.Country,
                              ZipCode = b.ZipCode,
                              a.PaymentDetail,
                              a.TotalAmount,
                              a.OrderDueOn
                          }).ToList();
            return result;
        }



        void IOrderService.PostOrder(Order order)
        {
            order.OrderStatus = "Not Paid";
            if (order.CustomerId == 0)
            {

                appDbContext.Customers.Add(order.Customer);
            }

            //Order Table
            if (order.OrderId == 0)
            {
                order.Customer = null;
                appDbContext.Orders.Add(order);
            }
            else
                appDbContext.Entry(order).State = EntityState.Modified;


            //OrderItems Table
            foreach (var item in order.OrderItems)
            {
                if (item.OrderItemId == 0)
                    appDbContext.OrderItems.Add(item);
                else
                    appDbContext.Entry(item).State = EntityState.Modified;
            }

            if (!string.IsNullOrEmpty(order.DeletedOrderItemIDs))
            {
                var deleteArray = order.DeletedOrderItemIDs.Split(',');
                foreach (var id in deleteArray)
                {
                    var intId = Convert.ToInt32(id);
                    OrderItem x = appDbContext.OrderItems.Find(intId);
                    appDbContext.OrderItems.Remove(x);
                }
            }

            appDbContext.SaveChanges();

        }
    }
}