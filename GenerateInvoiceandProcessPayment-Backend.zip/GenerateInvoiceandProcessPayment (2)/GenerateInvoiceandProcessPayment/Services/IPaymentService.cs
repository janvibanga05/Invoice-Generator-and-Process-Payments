using System.Collections.Generic;
using AuthorizeNet.Api.Contracts.V1;
using GenerateInvoiceandProcessPayment.Models.Entity;

namespace GenerateInvoiceandProcessPayment.Services
{
    public interface IPaymentService
    {
        void AddPayment(Payment payment, int id);
        ANetApiResponse DoPayment(string CardNumber, string ExpirationDate, decimal Amount);
        void CreateCardNumberHash(string CardNumber, string ExpirationDate, /*out byte[] CardNumberHash,*/ out byte[] ExpirationDateHash, out byte[] salt);
        System.Object GetPaymentDetails(int id);
    }
}