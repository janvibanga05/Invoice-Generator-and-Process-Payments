using GenerateInvoiceandProcessPayment.Models.Entity;
using GenerateInvoiceandProcessPayment.ViewModel.DTO;

namespace GenerateInvoiceandProcessPayment.Services
{
    public interface ICustomerService
    {
        IEnumerable<Customer> GetCustomers();
        Task<int> PostCustomer(CustomerDTO model);
    }
}