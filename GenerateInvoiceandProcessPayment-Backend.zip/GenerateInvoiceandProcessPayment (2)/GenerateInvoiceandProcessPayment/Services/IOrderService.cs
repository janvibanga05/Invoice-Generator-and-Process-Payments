using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GenerateInvoiceandProcessPayment.Models.Entity;

namespace GenerateInvoiceandProcessPayment.Services
{
    public interface IOrderService
    {
        System.Object GetOrders();
        System.Object GetOrder(int id);
        void PostOrder(Order order);
        void DeleteOrder(int id);
    }
}