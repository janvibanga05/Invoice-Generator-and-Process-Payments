using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GenerateInvoiceandProcessPayment.Models.Entity;
using GenerateInvoiceandProcessPayment.Models.EntityMapper;
using Microsoft.EntityFrameworkCore;

namespace GenerateInvoiceandProcessPayment.Database
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions dbContextOptions) : base(dbContextOptions)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            new CustomerEntityMapper(modelBuilder.Entity<Customer>());
            new ItemEntityMapper(modelBuilder.Entity<Item>());
            new OrderItemEntityMapper(modelBuilder.Entity<OrderItem>());
            new OrderEntityMapper(modelBuilder.Entity<Order>());
            new PaymentEntityMapper(modelBuilder.Entity<Payment>());
            new RefundEntityMapper(modelBuilder.Entity<Refund>());
            
            //For Testing seeded Data

            // modelBuilder.Entity<Item>().HasData(
            //        new Item
            //        {
            //            ItemId = 1,
            //            ItemName = "ZARA TUBE TOP",
            //            ItemDescription = "LEATHER TUBE TOP ",
            //            ItemPrice = 1700,

            //        });
            // modelBuilder.Entity<Item>().HasData(
            //   new Item
            //   {
            //       ItemId = 2,
            //       ItemName = "BELL BOTTOM JEANS",
            //       ItemDescription = "Women Bell Bottom Jeans",
            //       ItemPrice = 2500,

            //   });
            // modelBuilder.Entity<Item>().HasData(
            // new Item
            // {
            //     ItemId = 3,
            //     ItemName = "Nike AirMax 200",
            //     ItemDescription = "Nike Women Air Max Shoes",
            //     ItemPrice = 10000,

            // });
            // modelBuilder.Entity<Item>().HasData(
            // new Item
            // {
            //     ItemId = 4,
            //     ItemName = "Baggy-TShirt",
            //     ItemDescription = "H&M Women Baggy TShirt",
            //     ItemPrice = 1000,

            // });
            // modelBuilder.Entity<Item>().HasData(
            // new Item
            // {
            //     ItemId = 5,
            //     ItemName = "Belted Blazer Dress",
            //     ItemDescription = "Maroon Belted Blazer Dress",
            //     ItemPrice = 2700,

            // });
            // modelBuilder.Entity<Item>().HasData(
            // new Item
            // {
            //     ItemId = 6,
            //     ItemName = "H&M Knee-High Heeled Boots",
            //     ItemDescription = "H&M Black Knee-High Heeled Boots ",
            //     ItemPrice = 5000,

            // });
            // modelBuilder.Entity<Item>().HasData(
            // new Item
            // {
            //     ItemId = 7,
            //     ItemName = "Micheal Kors Women Watch",
            //     ItemDescription = "Micheal Kors BradShaw Women Gold Analogue Watch MK6359",
            //     ItemPrice = 9999,

            // });
            // modelBuilder.Entity<Item>().HasData(
            // new Item
            // {
            //     ItemId = 8,
            //     ItemName = "Charles & Keith Bag",
            //     ItemDescription = "Geometric Push-Lock Top Handle Bag-Black",
            //     ItemPrice = 9500,

            // });

        }
        //Using DbSet to create table in Database
        public virtual DbSet<Customer> Customers { get; set; }
        public virtual DbSet<Item> Item { get; set; }
        public virtual DbSet<Order> Orders { get; set; }
        public virtual DbSet<OrderItem> OrderItems { get; set; }
        public virtual DbSet<Payment> Payments { get; set; }
        public virtual DbSet<Refund> Refunds { get; set; }
    }
}