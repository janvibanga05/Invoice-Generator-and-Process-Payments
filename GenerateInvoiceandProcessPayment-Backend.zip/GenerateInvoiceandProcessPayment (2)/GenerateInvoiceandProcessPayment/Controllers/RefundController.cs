using GenerateInvoiceandProcessPayment.Database;
using GenerateInvoiceandProcessPayment.Models.Entity;
using GenerateInvoiceandProcessPayment.Services;
using GenerateInvoiceandProcessPayment.ViewModel.DTO;
using Microsoft.AspNetCore.Mvc;
using AuthorizeNet.Api.Contracts.V1;
using System.Linq;

namespace GenerateInvoiceandProcessPayment.Controllers
{
    [ApiController]
    [Route("[controller]")]

    public class RefundController : ControllerBase
    {
        IRefundService refundService;
        AppDbContext appDbContext;
        public RefundController(IRefundService _refundService, AppDbContext _context)
        {
            refundService = _refundService;
            appDbContext = _context;
        }

        //Process Refund using Transaction ID and Amount
        [HttpPost]

        public IActionResult RefundPayment(RefundDTO refundDTO)
        {
            Console.WriteLine("Hello");
            System.Console.WriteLine(System.Text.Encoding.UTF8.GetString(appDbContext.Payments.FirstOrDefault(p => p.TransactionId == refundDTO.TransactionId).CardNumber));
            var response = refundService.Run(refundDTO.Amount, refundDTO.TransactionId);
            if (response.messages.resultCode == messageTypeEnum.Ok)
            {
                Refund refund1 = new Refund(refundDTO);
                
            }

             Refund refund2 = new Refund(refundDTO);

             refundService.PostItem(refund2);
            return Ok(response);
        }
    }
}