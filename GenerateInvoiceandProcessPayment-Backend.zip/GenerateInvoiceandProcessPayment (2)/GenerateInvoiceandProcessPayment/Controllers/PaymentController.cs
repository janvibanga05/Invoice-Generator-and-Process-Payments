using Microsoft.AspNetCore.Mvc;
using AuthorizeNet.Api.Contracts.V1;
using GenerateInvoiceandProcessPayment.Services;
using GenerateInvoiceandProcessPayment.ViewModel.DTO;
using GenerateInvoiceandProcessPayment.Models.Entity;
namespace GenerateInvoiceandProcessPayment.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PaymentController : ControllerBase
    {
        IPaymentService paymentservice;
        public PaymentController( IPaymentService _paymentService)
        {
            paymentservice = _paymentService;
        }

         //Create Payment and for Calling Authorize.net payment process
        
        [HttpPost]
        public IActionResult PostPayment(PaymentDTO paymentViewModel)
        {
            byte[]/* CardNumberHash,*/ expirationDateHash, salt;
             paymentservice.CreateCardNumberHash( paymentViewModel.CardNumber,paymentViewModel.ExpirationDate, /*out CardNumberHash,*/ out expirationDateHash, out salt);


            var response =  paymentservice.DoPayment( paymentViewModel.CardNumber,paymentViewModel.ExpirationDate,  paymentViewModel.Amount);

            if (response.messages.resultCode == messageTypeEnum.Ok)
            {
                Payment payment1 = new Payment(paymentViewModel,expirationDateHash,salt);
                
                paymentservice.AddPayment(payment1,paymentViewModel.OrderId);
            }
            return Ok(response);
        }

        //Get Payment Details by ID
        [HttpGet("{id}")]
        public IActionResult FetchItems(int id)
        {
            return Ok(paymentservice.GetPaymentDetails(id));
        }
        
    }
}