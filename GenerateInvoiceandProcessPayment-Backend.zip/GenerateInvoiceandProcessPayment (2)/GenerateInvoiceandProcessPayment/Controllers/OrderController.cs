using GenerateInvoiceandProcessPayment.Models.Entity;
using GenerateInvoiceandProcessPayment.Services;
using Microsoft.AspNetCore.Mvc;

namespace GenerateInvoiceandProcessPayment.Controllers
{   [ApiController]
    [Route("[controller]")]

    public class OrderController : ControllerBase
    {
        IOrderService orderService;

        public OrderController(IOrderService _orderService)
        {
            orderService=_orderService;
        }

        //Create Order
        [HttpPost]
        public IActionResult AddOrder(Order order)
        {
            orderService.PostOrder(order);
            return Ok(order);
        }

        [HttpGet]
        public IActionResult FetchOrders()
        {
            return Ok(orderService.GetOrders());
        }

        //Get Order Details by ID
        [HttpGet("{id}")]
        public IActionResult FetchOrderById(int id)
        {
            System.Console.WriteLine("Test");
            return Ok(orderService.GetOrder(id));
        }

        //Delete Order
        [HttpDelete("{id}")]
        public IActionResult RemoveOrderById(int id)
        {
            orderService.DeleteOrder(id);
            return NoContent();
        } 
    }
}