using GenerateInvoiceandProcessPayment.Services;
using GenerateInvoiceandProcessPayment.ViewModel.DTO;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using GenerateInvoiceandProcessPayment.Models.Entity;


namespace GenerateInvoiceandProcessPayment.Controllers
{
    [ApiController]
    [Route("[controller]")]

    public class ItemController : ControllerBase
    {
        IItemService itemService;
        public ItemController(IItemService _itemService)
        {
            itemService = _itemService;
        }
        //Get Item Details
        [HttpGet]
        public IActionResult FetchItems()
        {
            var result = itemService.GetItems();
            return Ok(result);
        }

        //Create Item 
        [HttpPost]
        public async Task<IActionResult> CreateItem(ItemDTO model)
        {

            var item = new Item(model);
            return Ok(await itemService.PostItem(item));
        }

        [HttpDelete]

        [Route("Deleteproduct/{id}")]

        public async Task<IActionResult> Deleteitem(int id)

        {

            await itemService.Deleteitem(id);

            return NoContent();

        }
    }
}