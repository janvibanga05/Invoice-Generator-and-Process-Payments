using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GenerateInvoiceandProcessPayment.Services;
using Microsoft.AspNetCore.Mvc;
using GenerateInvoiceandProcessPayment.Models.Entity;
using GenerateInvoiceandProcessPayment.ViewModel.DTO;
using FluentValidation;

namespace GenerateInvoiceandProcessPayment.Controllers
{
    [ApiController]
    [Route("[controller]")] //For URL
    public class CustomerController : ControllerBase
    {
        ICustomerService customerService;
        public CustomerController(ICustomerService _customerService)
        {
            customerService = _customerService;
        }
        [HttpGet]
        public IActionResult Fetchcustomers()
        {
            return Ok(customerService.GetCustomers());
        }
        [HttpPost]
        public async Task<IActionResult> CreateCustomer(CustomerDTO model)
        {

            return Ok(await customerService.PostCustomer(model));
        }



    }
}