using GenerateInvoiceandProcessPayment.Database;
using GenerateInvoiceandProcessPayment.Services;
using Microsoft.EntityFrameworkCore;
using FluentValidation.AspNetCore;
using GenerateInvoiceandProcessPayment.ViewModel.DTOVALIDATION;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers(); //IServiceCollection
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddCors();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<AppDbContext>(d => d.UseNpgsql(builder.Configuration.GetConnectionString("dbConnection")));
builder.Services.AddControllersWithViews().AddNewtonsoftJson(options => options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore);
builder.Services.AddControllers().AddFluentValidation(f => f.RegisterValidatorsFromAssemblyContaining<CustomerViewModelValidation>());       //Registring Fluent Validation
builder.Services.AddTransient<ICustomerService, CustomerService>(); ///
builder.Services.AddTransient<IItemService, ItemService>();
builder.Services.AddTransient<IPaymentService, PaymentService>();
builder.Services.AddTransient<IOrderService, OrderService>();
builder.Services.AddTransient<IRefundService, RefundService>();
var app = builder.Build();
app.UseCors(x => x
.AllowAnyMethod()
.AllowAnyHeader()
.SetIsOriginAllowed(origin => true)
.AllowCredentials());

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())  //IApplicationBuilder
{
    app.UseSwagger();
    app.UseSwaggerUI();
}


app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
