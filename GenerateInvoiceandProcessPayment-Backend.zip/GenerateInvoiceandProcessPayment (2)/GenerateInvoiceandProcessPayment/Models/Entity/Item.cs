using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GenerateInvoiceandProcessPayment.ViewModel.DTO;

namespace GenerateInvoiceandProcessPayment.Models.Entity
{
    public class Item
    {
        public int ItemId { get; set; }
        public string ItemName { get; set; }
        public string ItemDescription { get; set; }
        public float ItemPrice { get; set; }

        //Applying Navigation Property
        public virtual ICollection<OrderItem> OrderItems { get; set; }

        public Item(ItemDTO model)
        {
            ItemId = model.ItemId;
            ItemName = model.ItemName;
            ItemDescription = model.ItemDescription;
            ItemPrice = model.ItemPrice;

        }
        public Item()
        {
            
        }
    }
}
