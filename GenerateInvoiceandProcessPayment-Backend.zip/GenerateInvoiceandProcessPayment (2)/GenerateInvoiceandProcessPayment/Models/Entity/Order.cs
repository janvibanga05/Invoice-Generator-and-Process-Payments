using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GenerateInvoiceandProcessPayment.Models.Entity
{
    public class Order
    {
        public int OrderId { get; set; } //Primary key
        public string OrderNumber { get; set; }
        public int CustomerId { get; set; } //Foreign key
        public string PaymentDetail { get; set; }
        public float TotalAmount { get; set; }
        public string OrderStatus { get; set; }
        public string OrderDueOn { get; set; }
        public string DeletedOrderItemIDs { get; set; }

        //Applying Navigation Property
        public virtual Customer Customer { get; set; }
        public virtual ICollection<OrderItem> OrderItems { get; set; }
        public virtual ICollection<Payment> Payments { get; set; }
    }
}