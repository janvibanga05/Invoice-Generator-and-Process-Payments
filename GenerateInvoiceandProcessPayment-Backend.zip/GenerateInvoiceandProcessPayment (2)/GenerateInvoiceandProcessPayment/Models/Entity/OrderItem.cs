using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GenerateInvoiceandProcessPayment.Models.Entity
{
    public class OrderItem
    {
        public int OrderItemId { get; set; }  //Primary key
        public int OrderId { get; set; } //Foriegn key
        public int ItemId { get; set; }
        public int Quantity { get; set; }

        //Applying Navigation Property
        public virtual Item Item { get; set; }
        public virtual Order Order { get; set; } 
    }
}