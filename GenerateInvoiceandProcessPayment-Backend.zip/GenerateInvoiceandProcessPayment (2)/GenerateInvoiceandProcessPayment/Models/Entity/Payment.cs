using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GenerateInvoiceandProcessPayment.ViewModel.DTO;

namespace GenerateInvoiceandProcessPayment.Models.Entity
{
    public class Payment
    {
        public int PaymentId { get; set; }
        public int OrderId { get; set; }
        public string CardOwnerName { get; set; }
        public byte[] CardNumber { get; set; }
        public byte[] Salt { get; set; } //used for passwords
        public byte[] ExpirationDate { get; set; }
        public decimal Amount { get; set; }
        public string TransactionId { get; set; }

        //Applying Navigation Property
        public virtual Order Order { get; set; }
        public virtual Refund Refund { get; set; }


        public Payment(PaymentDTO paymentDTO, byte[] expirationDateHash, byte[] salt)
        {
            OrderId = paymentDTO.OrderId;
            CardOwnerName = paymentDTO.CardOwnerName;
            Amount = paymentDTO.Amount;
            CardNumber = System.Text.Encoding.UTF8.GetBytes(paymentDTO.CardNumber);
            ExpirationDate = expirationDateHash;
            Salt = Salt;

        }
        public Payment()
        {
            
        }
    }
}