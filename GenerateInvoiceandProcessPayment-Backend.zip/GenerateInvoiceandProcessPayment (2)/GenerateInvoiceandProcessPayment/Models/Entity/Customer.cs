using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GenerateInvoiceandProcessPayment.ViewModel.DTO;

namespace GenerateInvoiceandProcessPayment.Models.Entity
{
    public class Customer
    {

        public int CustomerId { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string ZipCode { get; set; }
        public string CustomerName { get; set; }
        public string CustomerEmail { get; set; }
        
        //Applying Navigation Property
        public virtual ICollection<Order> Orders { get; set; }

        public Customer(CustomerDTO model)  //Single Responsibility Pattern for reusability 
        {
            CustomerId = model.CustomerId;
            CustomerName = model.CustomerName;
            CustomerEmail = model.CustomerEmail;
            AddressLine1 = model.AddressLine1;
            AddressLine2 = model.AddressLine2;
            State = model.State;
            City = model.City;
            Country = model.Country;
            ZipCode = model.ZipCode;


        }
        public Customer()
        {

        }
    }
}