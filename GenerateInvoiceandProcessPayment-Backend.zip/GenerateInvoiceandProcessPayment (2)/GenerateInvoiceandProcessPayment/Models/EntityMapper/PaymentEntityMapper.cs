using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GenerateInvoiceandProcessPayment.Models.Entity;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GenerateInvoiceandProcessPayment.Models.EntityMapper
{
    public class PaymentEntityMapper
    {
        public PaymentEntityMapper(EntityTypeBuilder<Payment> entityTypeBuilder)
        {
           //Applying FluentApi for defining constraints and required fields
            entityTypeBuilder.HasKey(i => i.PaymentId);
            entityTypeBuilder.Property(i => i.OrderId).ValueGeneratedOnAdd();                          //Auto generation of ID

            //Applying One to Many relationship
            entityTypeBuilder.HasOne(i => i.Order).WithMany(i => i.Payments).HasForeignKey(i => i.OrderId);

        }
    }
}