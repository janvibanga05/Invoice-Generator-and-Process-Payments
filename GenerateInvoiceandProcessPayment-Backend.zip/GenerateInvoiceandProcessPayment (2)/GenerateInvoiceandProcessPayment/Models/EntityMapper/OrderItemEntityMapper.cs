using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GenerateInvoiceandProcessPayment.Models.Entity;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GenerateInvoiceandProcessPayment.Models.EntityMapper
{
    public class OrderItemEntityMapper
    {
        public OrderItemEntityMapper(EntityTypeBuilder<OrderItem> entityTypeBuilder)
        {
            entityTypeBuilder.HasKey(i => i.OrderItemId);
            entityTypeBuilder.Property(i => i.OrderItemId).ValueGeneratedOnAdd();   //Auto generation of ID

            //Applying One to Many relationship
            entityTypeBuilder.HasOne(i => i.Item).WithMany(i => i.OrderItems).HasForeignKey(i => i.ItemId);
            entityTypeBuilder.HasOne(i => i.Order).WithMany(i => i.OrderItems).HasForeignKey(i => i.OrderId);
        }
    }
}