using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GenerateInvoiceandProcessPayment.Models.Entity;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GenerateInvoiceandProcessPayment.Models.EntityMapper
{
    public class CustomerEntityMapper
    {
        public CustomerEntityMapper(EntityTypeBuilder<Customer>entityTypeBuilder)
        {
            entityTypeBuilder.HasKey(i => i.CustomerId);
            entityTypeBuilder.Property(i => i.CustomerId).ValueGeneratedOnAdd();    //Auto generation of ID
            entityTypeBuilder.Property(i => i.CustomerName).IsRequired();
            entityTypeBuilder.Property(i => i.CustomerEmail).IsRequired();
            entityTypeBuilder.Property(i => i.AddressLine1).IsRequired();
            entityTypeBuilder.Property(i => i.City).IsRequired();
            entityTypeBuilder.Property(i => i.State).IsRequired();
            entityTypeBuilder.Property(i => i.Country).IsRequired();
            entityTypeBuilder.Property(i=>i.ZipCode).IsRequired();
        }
    }
}