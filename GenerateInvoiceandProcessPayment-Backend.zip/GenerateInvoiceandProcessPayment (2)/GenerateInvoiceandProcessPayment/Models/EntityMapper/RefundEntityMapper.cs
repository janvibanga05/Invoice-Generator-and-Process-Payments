using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GenerateInvoiceandProcessPayment.Models.Entity;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GenerateInvoiceandProcessPayment.Models.EntityMapper
{
    public class RefundEntityMapper
    {
        public RefundEntityMapper(EntityTypeBuilder<Refund> entityTypeBuilder)
        {
            //Applying FluentApi for defining constraints and required fields
            entityTypeBuilder.HasKey(i => i.RefundId);
            entityTypeBuilder.Property(i => i.RefundId).ValueGeneratedOnAdd();     //Auto generation of ID

            //Applying One to One relationship
            entityTypeBuilder.HasOne(i => i.Payment).WithOne(i => i.Refund).HasForeignKey<Refund>(i => i.TransactionId).HasPrincipalKey<Payment>(i => i.TransactionId);
            entityTypeBuilder.HasOne(i => i.Payment).WithOne(i => i.Refund).HasForeignKey<Refund>(i => i.Amount).HasPrincipalKey<Payment>(i => i.Amount); 
        }
    }
}