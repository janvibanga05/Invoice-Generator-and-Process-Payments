using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GenerateInvoiceandProcessPayment.Models.Entity;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GenerateInvoiceandProcessPayment.Models.EntityMapper
{
    public class ItemEntityMapper
    {
        public ItemEntityMapper(EntityTypeBuilder<Item> entityTypeBuilder)
        {
            entityTypeBuilder.HasKey(i => i.ItemId);
            entityTypeBuilder.Property(i => i.ItemId).ValueGeneratedOnAdd();  //Auto generation of ID
            entityTypeBuilder.Property(i => i.ItemName).IsRequired();
            entityTypeBuilder.Property(i => i.ItemDescription).IsRequired();
            entityTypeBuilder.Property(i => i.ItemPrice).IsRequired();
        }
    }
}